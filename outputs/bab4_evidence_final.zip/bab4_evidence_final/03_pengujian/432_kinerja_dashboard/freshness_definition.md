T0=dataset diterima; T1=Gold selesai; T2=dashboard tersedia. Pipeline latency=T1-T0; refresh delay=T2-T1; freshness=T2-T0. Tidak dihitung tanpa ketiga timestamp.
