# Limitations

- dataset aktif bukan COMMITTED
