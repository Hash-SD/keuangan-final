# Evidence Index

| subsection | status | evidence |
|---|---|---|
| 4.1.1 | READY | profil workbook/sheet |
| 4.1.2 | READY | inventaris aturan dan komponen |
| 4.1.3 | READY | dictionary, lineage, trace samples |
| 4.2.1 | READY | Airflow DAG/run/task evidence |
| 4.2.2 | READY WITH LIMITATIONS | artefak Bronze/Silver lokal |
| 4.2.3 | READY WITH LIMITATIONS | Gold lokal; storage/query konservatif |
| 4.3.1 | NOT READY | rekonsiliasi lingkup sama hanya tersedia 2025; kontrol 2023/2024 belum ada |
| 4.3.2 | NOT READY | freshness T0/T2 tidak tersedia pada artefak aktif |
| 4.3.3 | READY WITH LIMITATIONS | UAT portal satu pengguna utama; alignment 5 vs 7 indikator |
