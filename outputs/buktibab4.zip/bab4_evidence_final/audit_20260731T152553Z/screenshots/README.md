# Instruksi Screenshot untuk User

Ambil screenshot aktual berikut setelah membuka sistem:

- Docker Compose: daftar service dan health status.
- Airflow Grid: DAG run canonical dan status task.
- Airflow Graph: dependensi task.
- Log task pipeline: extraction, Bronze, Silver, Gold, PostgreSQL, Superset.
- MinIO: object path canonical Bronze/Silver/Gold.
- PostgreSQL/Trino: hasil query count dan weighted total.
- Superset: dashboard, filter tahun/IKU/kegiatan/akun, KPI, grafik, detail item, dan lineage.

Jangan menampilkan password, token, cookie, access key, atau secret key. Simpan dengan nama file yang sama seperti daftar di atas dan cantumkan timestamp serta canonical run ID.
