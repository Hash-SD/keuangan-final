# Limitations

- `data/generated/excel_lakehouse_metadata.json` masih menunjuk pipeline run lama; bukti canonical memakai `active_gold_run.json`, `pipeline_runs/<pipeline_run_id>.json`, dan `storage_manifest.json` yang konsisten.
- Jumlah Bronze pada CSV lokal canonical adalah 55.340, sedangkan storage manifest mencatat 55.558; mismatch ini belum boleh dianggap rekonsiliasi final.
- Bukti lima run untuk statistik latency/freshness T0–T1–T2 belum tersedia dalam satu scope yang dapat diverifikasi.
- UAT memiliki satu submission lokal, tetapi belum memuat skor atau jawaban indikator aktual.
- Screenshot sistem belum diklaim. User harus mengambil screenshot aktual sesuai `screenshots/README.md`.
- Iceberg hanya dapat dinyatakan `CONFIGURED_ONLY` bila tidak ada snapshot/query operasional yang terbukti.
